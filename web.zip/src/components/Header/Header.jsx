import "./Header.css";
import { Link } from "react-router-dom";

export function Header() {
  return (
    <header className="header">
      <h1>Park Hřiště</h1>
      <nav className="menu">
        <Link to="/" className="menu-link">Domů</Link>
        <Link to="mapa" className="menu-link">Mapa</Link>
        <Link to="list" className="menu-link">Hřiště</Link>
        <Link to="about" className="menu-link">O nás</Link>
      </nav>
    </header>
  );
}