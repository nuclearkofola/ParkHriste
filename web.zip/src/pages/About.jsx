
export function About(){
    return(
        <>
        <h1>About</h1>
        <ul>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci unde alias a similique tempore blanditiis. Vero exercitationem vitae reiciendis labore quam eaque ducimus voluptatum error eius officia est, rem nemo.</li>
            <li>Corporis praesentium consequatur recusandae distinctio, cupiditate repellat tenetur quis veniam fugit hic illum sunt aliquid modi ratione? Alias debitis dolores rem! Commodi, quidem nulla. Vel dignissimos sint aspernatur nemo similique?</li>
            <li>Quisquam quaerat officia voluptas dignissimos molestias deleniti saepe laudantium fugiat dicta odio odit aut, excepturi harum assumenda voluptatibus doloribus aliquam sit quod in sed! At repudiandae nihil libero! Aut, quibusdam!</li>
            <li>Omnis, consequuntur molestiae explicabo delectus suscipit recusandae dolorem dolores ad veniam necessitatibus perferendis enim et animi impedit debitis cumque natus laboriosam tempore ipsa nesciunt corrupti cupiditate. Quisquam eligendi voluptatibus iste!</li>
            <li>Tempora at, perspiciatis quis, cum aperiam repudiandae laboriosam nisi sequi sint impedit nihil tenetur. Sapiente possimus dignissimos minima molestiae neque, vel quaerat magnam nulla quo pariatur voluptatem molestias laboriosam veritatis.</li>
        </ul>
        </>
    )
}