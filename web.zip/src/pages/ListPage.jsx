
export function ListPage(){
    return(
        <>
        <h1>ListPage</h1>
        <ul>
            <li>Lorem ipsum dolor sit amet consectetur adipisicing elit. Adipisci unde alias a similique tempore blanditiis. Vero exercitationem vitae reiciendis labore quam eaque ducimus voluptatum error eius officia est, rem nemo.</li>
            <li>Corporis praesentium consequatur recusandae distinctio, cupiditate repellat tenetur quis veniam fugit hic illum sunt aliquid modi ratione? Alias debitis dolores rem! Commodi, quidem nulla. Vel dignissimos sint aspernatur nemo similique?</li>
        </ul>
        </>
    )
}