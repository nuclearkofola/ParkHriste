import AppMap from "../components/AppMap/AppMap";

export function MapPage(){
    return(
        <>
        <h1>Mapa</h1>
        <AppMap />
        </>
    )
}